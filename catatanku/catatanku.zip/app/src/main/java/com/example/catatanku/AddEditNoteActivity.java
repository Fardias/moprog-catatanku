package com.example.catatanku;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import androidx.exifinterface.media.ExifInterface;
import android.os.Build;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.catatanku.models.Note;
import com.example.catatanku.utils.Constants;
import com.example.catatanku.utils.MultipartRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


public class AddEditNoteActivity extends AppCompatActivity {
    private EditText titleEditText, contentEditText;
    private Button saveButton;
    private ImageView noteImageView;
    private LinearLayout addImageContainer;
    private RequestQueue requestQueue;
    private SharedPreferences sharedPreferences;
    private Note noteToEdit;
    private boolean isEditMode = false;
    private static final int GALLERY_PERMISSION_CODE = 100;
    private static final int MAX_IMAGE_SIZE_KB = 500;
    private File compressedImageFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_note);

        sharedPreferences = getSharedPreferences("CatatankuPrefs", MODE_PRIVATE);
        requestQueue = Volley.newRequestQueue(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        titleEditText = findViewById(R.id.titleEditText);
        contentEditText = findViewById(R.id.contentEditText);
        saveButton = findViewById(R.id.saveButton);
        noteImageView = findViewById(R.id.noteImageView);
        addImageContainer = findViewById(R.id.addImageContainer);

        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        try {
            if (getIntent() != null && getIntent().hasExtra("note")) {
                noteToEdit = getIntent().getParcelableExtra("note");
                if (noteToEdit != null) {
                    isEditMode = true;
                    titleEditText.setText(noteToEdit.getTitle());
                    contentEditText.setText(noteToEdit.getContent());
                    getSupportActionBar().setTitle("Ubah Catatan");

                    if (noteToEdit.getImagePath() != null && !noteToEdit.getImagePath().isEmpty()) {
                        String imageUrl = Constants.BASE_URL + "/notes/" + noteToEdit.getId() + "/image";
                        Glide.with(this)
                                .load(imageUrl + "?t=" + System.currentTimeMillis())
                                .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .skipMemoryCache(true)
                                .placeholder(R.drawable.placeholder_image)
                                .error(R.drawable.placeholder_image)
                                .into(noteImageView);
                        noteImageView.setVisibility(View.VISIBLE);
                        addImageContainer.setVisibility(View.GONE);
                    } else {
                        noteImageView.setVisibility(View.GONE);
                        addImageContainer.setVisibility(View.VISIBLE);
                    }
                } else {
                    showErrorAndFinish("Data catatan tidak valid");
                }
            } else {
                getSupportActionBar().setTitle("Tambah Catatan");
                noteImageView.setVisibility(View.GONE);
                addImageContainer.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            showErrorAndFinish("Gagal memuat catatan: " + e.getMessage());
        }

        saveButton.setOnClickListener(v -> saveNote());

        View.OnClickListener openGalleryListener = v -> checkPermissionAndOpenGallery();
        addImageContainer.setOnClickListener(openGalleryListener);
        noteImageView.setOnClickListener(openGalleryListener);
    }


    private void saveNote() {
        String title = titleEditText.getText().toString().trim();
        String content = contentEditText.getText().toString().trim();
        int userId = getUserId();

        if (title.isEmpty()) {
            titleEditText.setError("Judul tidak boleh kosong");
            return;
        }

        if (userId == -1) {
            Toast.makeText(this, "Anda belum login", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String url = Constants.BASE_URL + (isEditMode ? "/notes/" + noteToEdit.getId() : "/notes");
        Map<String, String> params = new HashMap<>();
        params.put("title", title);
        params.put("content", content);
        params.put("user_id", String.valueOf(userId));

        MultipartRequest.Part imagePart = null;
        if (compressedImageFile != null && compressedImageFile.exists()) {
            imagePart = new MultipartRequest.Part("image", "image/jpeg", compressedImageFile);
        } else if (isEditMode && noteToEdit.getImagePath() != null && !noteToEdit.getImagePath().isEmpty()) {
            params.put("existing_image", noteToEdit.getImagePath());
        }

        MultipartRequest request = new MultipartRequest(
                isEditMode ? Request.Method.PUT : Request.Method.POST,
                url,
                params,
                imagePart,
                response -> {
                    try {
                        if (response.getBoolean("success")) {
                            if (response.has("data")) {
                                JSONObject data = response.getJSONObject("data");
                                // PERBAIKAN: Tukar urutan argumen terakhir
                                Note noteResult = new Note(
                                        data.optInt("id"),
                                        data.optString("title"),
                                        data.optString("content"),
                                        data.optString("image_path"), // image_path dulu
                                        data.optString("created_at")  // baru created_at
                                );

                                if (isEditMode) {
                                    Intent resultIntent = new Intent();
                                    resultIntent.putExtra("updatedNote", noteResult);
                                    setResult(RESULT_OK, resultIntent);
                                    Toast.makeText(this, "Catatan berhasil diperbarui", Toast.LENGTH_SHORT).show();
                                } else {
                                    Intent intent = new Intent(this, NoteDetailActivity.class);
                                    intent.putExtra("note", noteResult);
                                    startActivity(intent);
                                    Toast.makeText(this, "Catatan berhasil dibuat", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                setResult(RESULT_OK);
                            }
                            finish();
                        } else {
                            String message = response.getString("message");
                            Toast.makeText(this, "Error: " + message, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Error parsing response: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },

                error -> {
                    //
                }
        );
        String token = getSharedPreferences("CatatankuPrefs", MODE_PRIVATE).getString("token", null);
        if (token != null) {
            request.setHeader("Authorization", "Bearer " + token);
        }
        request.setRetryPolicy(new DefaultRetryPolicy(30000, 3, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(request);
    }

    private int getUserId() {
        return sharedPreferences.getInt("userId", -1);
    }

    private String getToken() {
        return sharedPreferences.getString("token", null);
    }

    @SuppressLint("InlinedApi")
    private void checkPermissionAndOpenGallery() {
        String permission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;

        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                showPermissionRationaleDialog();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{permission}, GALLERY_PERMISSION_CODE);
            }
        } else {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            galleryLauncher.launch(intent);
        }
    }

    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri selectedImageUri = result.getData().getData();
                    if (selectedImageUri != null) {
                        try {
                            processAndDisplayImage(selectedImageUri);
                        } catch (IOException e) {
                            Toast.makeText(this, "Gagal memproses gambar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Gagal memilih gambar", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private void processAndDisplayImage(Uri imageUri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(imageUri);
        if (inputStream == null) {
            throw new IOException("Unable to open input stream for URI: " + imageUri);
        }

        Bitmap originalBitmap = BitmapFactory.decodeStream(inputStream);
        inputStream.close();
        Bitmap rotatedBitmap = rotateImageIfRequired(originalBitmap, imageUri);

        noteImageView.setImageBitmap(rotatedBitmap);
        noteImageView.setVisibility(View.VISIBLE);
        addImageContainer.setVisibility(View.GONE);

        compressImage(rotatedBitmap);
    }

    private Bitmap rotateImageIfRequired(Bitmap img, Uri selectedImage) throws IOException {
        InputStream input = getContentResolver().openInputStream(selectedImage);
        if (input == null) return img;

        ExifInterface ei;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ei = new ExifInterface(input);
        } else {
            String imagePath = getRealPathFromURI(selectedImage);
            if (imagePath == null) {
                input.close();
                return img;
            }
            ei = new ExifInterface(imagePath);
        }

        int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
        Matrix matrix = new Matrix();
        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90: matrix.postRotate(90); break;
            case ExifInterface.ORIENTATION_ROTATE_180: matrix.postRotate(180); break;
            case ExifInterface.ORIENTATION_ROTATE_270: matrix.postRotate(270); break;
            default:
                input.close();
                return img;
        }
        input.close();
        return Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, true);
    }

    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        try (Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null)) {
            if (cursor == null) return null;
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(columnIndex);
        } catch (Exception e) {
            return null;
        }
    }

    private void compressImage(Bitmap image) {
        if (image == null) return;
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            int quality = 85;
            image.compress(Bitmap.CompressFormat.JPEG, quality, bos);
            while (bos.size() > MAX_IMAGE_SIZE_KB * 1024 && quality > 20) {
                bos.reset();
                quality -= 5;
                image.compress(Bitmap.CompressFormat.JPEG, quality, bos);
            }
            File tempFile = File.createTempFile("note_img_", ".jpg", getCacheDir());
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(bos.toByteArray());
                compressedImageFile = tempFile;
            }
        } catch (IOException e) {
            compressedImageFile = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == GALLERY_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                galleryLauncher.launch(intent);
            } else {
                Toast.makeText(this, "Izin akses galeri dibutuhkan untuk memilih gambar", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showPermissionRationaleDialog() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Izin Diperlukan")
                .setMessage("Aplikasi membutuhkan izin untuk mengakses galeri.")
                .setPositiveButton("Buka Pengaturan", (dialog, which) -> {
                    Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                    intent.addCategory(Intent.CATEGORY_DEFAULT);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void showErrorAndFinish(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}