package com.example.catatanku;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.example.catatanku.models.Note;
import com.example.catatanku.utils.Constants;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class NoteDetailActivity extends AppCompatActivity  {

    private TextView titleTextView, contentTextView, dateTextView;
    private ImageView noteImageView;
    private Note note;
    private RequestQueue requestQueue;
    private SharedPreferences sharedPreferences;
    private boolean justReturnedFromEdit = false;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            Note updatedNote = data.getParcelableExtra("updatedNote");
            if (updatedNote != null) {
                this.note = updatedNote;
                this.justReturnedFromEdit = true;
                displayNote();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_detail);

        sharedPreferences = getSharedPreferences("CatatankuPrefs", MODE_PRIVATE);
        requestQueue = Volley.newRequestQueue(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Detail Catatan");
        }

        titleTextView = findViewById(R.id.titleTextView);
        contentTextView = findViewById(R.id.contentTextView);
        dateTextView = findViewById(R.id.dateTextView);
        noteImageView = findViewById(R.id.noteImageView);

        if (getIntent() != null && getIntent().hasExtra("note")) {
            note = getIntent().getParcelableExtra("note");
            if (note != null) {
                displayNote();
            } else {
                showErrorAndFinish("Data catatan tidak valid");
            }
        } else {
            showErrorAndFinish("Catatan tidak ditemukan");
        }
    }

    private void fetchNoteDetails() {
        Log.d("NoteDetail", "fetchNoteDetails() called.");
        String token = getToken();
        if (token == null) {
            return;
        }

        String url = Constants.BASE_URL + "/notes/" + note.getId();
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.GET, url, null,
                response -> {
                    try {
                        if (response.getBoolean("success")) {
                            JSONObject data = response.getJSONObject("data");
                            // PERBAIKAN: Tukar urutan argumen terakhir
                            note = new Note(
                                    data.optInt("id", -1),
                                    data.optString("title", "Tanpa Judul"),
                                    data.optString("content", ""),
                                    data.optString("created_at", ""),
                                    data.optString("image_path", null)
                            );
                            displayNote();
                        } else {
                            Toast.makeText(this, response.optString("message", "Gagal refresh data"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e("NoteDetail", "JSON parsing error on fetch: ", e);
                    }
                },
                error -> {
                    Log.e("NoteDetail", "Error fetching note details: " + error.toString());
                }
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }
        };
        requestQueue.add(request);
    }

    private void displayNote() {
        if (note == null) {
            showErrorAndFinish("Catatan tidak valid");
            return;
        }

        titleTextView.setText(note.getTitle());
        contentTextView.setText(note.getContent());
        dateTextView.setText(note.getCreatedAt());

        String imagePath = note.getImagePath();
        if (imagePath != null && !imagePath.isEmpty()) {
            String imageUrl = Constants.BASE_URL + "/notes/" + note.getId() + "/image?t=" + System.currentTimeMillis();
            noteImageView.setVisibility(View.VISIBLE);

            RequestOptions options = new RequestOptions()
                    .skipMemoryCache(true)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .placeholder(R.drawable.placeholder_image)
                    .error(R.drawable.placeholder_image)
                    .timeout(20000);

            Glide.with(this)
                    .load(imageUrl)
                    .apply(options)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            noteImageView.setImageResource(R.drawable.placeholder_image);
                            Toast.makeText(NoteDetailActivity.this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show();
                            return false;
                        }
                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            return false;
                        }
                    })
                    .into(noteImageView);
        } else {
            noteImageView.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.note_detail_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
            return true;
        } else if (id == R.id.action_edit) {
            Intent intent = new Intent(this, AddEditNoteActivity.class);
            intent.putExtra("note", note);
            startActivityForResult(intent, 1);
            return true;
        } else if (id == R.id.action_delete) {
            showDeleteConfirmationDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showDeleteConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Hapus catatan")
                .setMessage("Apakah Anda yakin ingin menghapus catatan ini?")
                .setPositiveButton("Hapus", (dialog, which) -> deleteNote())
                .setNegativeButton("Batal", null)
                .show();
    }

    private void deleteNote() {
        String token = getToken();
        if (token == null) {
            Toast.makeText(this, "Sesi berakhir, silakan login kembali.", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = Constants.BASE_URL + "/notes/" + note.getId();
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.DELETE, url, null,
                response -> {
                    try {
                        if (response.getBoolean("success")) {
                            Toast.makeText(this, "Catatan berhasil dihapus", Toast.LENGTH_SHORT).show();
                            setResult(RESULT_OK);
                            finish();
                        } else {
                            Toast.makeText(this, response.optString("message", "Gagal menghapus"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Gagal parsing respon", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Gagal menghapus catatan", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }
        };

        requestQueue.add(request);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (justReturnedFromEdit) {
            justReturnedFromEdit = false;
            return;
        }
        if (note != null) {
            fetchNoteDetails();
        }
    }

    private String getToken() {
        return sharedPreferences.getString("token", null);
    }

    private int getUserId() {
        return sharedPreferences.getInt("userId", -1);
    }

    private void showErrorAndFinish(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        finish();
    }
}