package com.example.catatanku.utils;

public class Constants {
    // Base URL for the API
    // For Android Emulator
    // public static final String BASE_URL = "http://10.0.2.2:5000/api";
    // If testing on a real device, use your computer's IP address instead
     public static final String BASE_URL = "http://192.168.100.7:5000/api";
}

// new features:
// crud profile page (done)
// upload file image for detial note (done)